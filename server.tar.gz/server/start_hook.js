require('babel-register')({
  presets: ['es2015-node4'],
});

require('./server.js');
