var contentNode = document.getElementById('contents');
var component = <h1 className="aColor">Hello World!</h1>;        // A simple component, written in JSX
ReactDOM.render(component, contentNode);      // Render the component inside the content Node
